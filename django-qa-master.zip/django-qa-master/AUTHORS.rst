=======
Credits
=======

The Begining
------------

django-qa was started by Arjun Komath (<arjunkomath@gmail.com>) in 2015 as a
way to have a simple and pluggable Q&A App for Django projects.

Development Lead
----------------

* Cristian Vargas <cristian@swapps.com>

Contributors
------------

Arjun Komath
Cristian Vargas
Sebastian Reyes
Jose Ariza
The SWAPPS development team
