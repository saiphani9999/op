.. django-qa documentation master file.
.. include:: base.rst

Welcome to django-qa's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   installation
   settings

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
